from dataclasses import dataclass, field
from typing import List, Dict

@dataclass
class Subject:
    id: str
    code: str
    name: str
    department: str
    credits: int
    required_sessions: int
    has_practical: bool
    practical_duration: int = 0
    practical_sessions_per_week: int = 0

@dataclass
class Teacher:
    id: str
    name: str
    department: str
    subjects: List[str]
    max_hours_per_day: int
    preferred_time_slots: List[str] = field(default_factory=list)

@dataclass
class Room:
    id: str
    name: str
    capacity: int
    has_projector: bool
    has_computers: bool
    is_lab: bool
    lab_type: str = ""

@dataclass
class TimeSlot:
    id: str
    day: str
    start_time: str
    end_time: str

@dataclass
class TimetableSession:
    subject: Subject
    teacher: Teacher
    room: Room
    time_slot: TimeSlot
    is_practical: bool

@dataclass
class Timetable:
    schedule: Dict[str, Dict[str, List[TimetableSession]]]
    conflicts: int = 0
    utilization: float = 0.0

