from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from io import BytesIO
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def generate_pdf(timetable):
    """
    Generate a PDF of the timetable.
    
    Args:
        timetable: A Timetable object
        
    Returns:
        A BytesIO buffer containing the PDF
    """
    try:
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=landscape(letter))
        elements = []
        
        styles = getSampleStyleSheet()
        title = Paragraph("College Timetable", styles['Title'])
        elements.append(title)
        elements.append(Spacer(1, 12))
        
        # Add timetable metadata
        metadata = Paragraph(f"Conflicts: {timetable.conflicts} | Resource Utilization: {timetable.utilization}%", styles['Normal'])
        elements.append(metadata)
        elements.append(Spacer(1, 12))
        
        # Get all days and time slots
        days = sorted(list(timetable.schedule.keys()))
        time_slots = sorted(list(set(time for day_schedule in timetable.schedule.values() for time in day_schedule.keys())))
        
        if not days or not time_slots:
            elements.append(Paragraph("No timetable data available.", styles['Normal']))
            doc.build(elements)
            return buffer
        
        # Create table data
        data = [['Time / Day'] + days]
        
        for time_slot in time_slots:
            row = [time_slot]
            for day in days:
                cell_content = ""
                if day in timetable.schedule and time_slot in timetable.schedule[day]:
                    sessions = timetable.schedule[day][time_slot]
                    for session in sessions:
                        cell_content += f"{session.subject.name}\n"
                        cell_content += f"{session.teacher.name}\n"
                        cell_content += f"{session.room.name}\n"
                        if session.is_practical:
                            cell_content += "LAB\n"
                        cell_content += "\n"
                row.append(cell_content)
            data.append(row)
        
        # Create the table
        table = Table(data)
        
        # Style the table
        table_style = TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (0, -1), colors.lightgrey),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('WORDWRAP', (0, 0), (-1, -1), True),
        ])
        table.setStyle(table_style)
        
        elements.append(table)
        doc.build(elements)
        
        return buffer
        
    except Exception as e:
        logger.error(f"Error generating PDF: {str(e)}")
        
        # Create a simple error PDF
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        elements = []
        
        styles = getSampleStyleSheet()
        title = Paragraph("Error Generating Timetable PDF", styles['Title'])
        elements.append(title)
        elements.append(Spacer(1, 12))
        
        error_text = Paragraph(f"An error occurred while generating the PDF: {str(e)}", styles['Normal'])
        elements.append(error_text)
        
        doc.build(elements)
        return buffer

