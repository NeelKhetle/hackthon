import random
import logging
from models.timetable import Subject, Teacher, Room, TimeSlot, TimetableSession, Timetable

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def generate_timetable(subjects, teachers, rooms, time_slots):
    """
    Generate a timetable using a genetic algorithm approach.
    
    Args:
        subjects: List of Subject objects
        teachers: List of Teacher objects
        rooms: List of Room objects
        time_slots: List of TimeSlot objects
        
    Returns:
        A Timetable object with the optimized schedule
    """
    try:
        # Validate input data
        if not subjects:
            raise ValueError("No subjects provided for timetable generation")
        if not teachers:
            raise ValueError("No teachers provided for timetable generation")
        if not rooms:
            raise ValueError("No rooms provided for timetable generation")
        if not time_slots:
            raise ValueError("No time slots provided for timetable generation")
            
        logger.info(f"Starting timetable generation with {len(subjects)} subjects, {len(teachers)} teachers, "
                   f"{len(rooms)} rooms, and {len(time_slots)} time slots")
        
        # Initialize population
        population_size = 10  # Reduced for faster execution
        population = []
        
        # Create initial population
        for _ in range(population_size):
            try:
                timetable = create_random_timetable(subjects, teachers, rooms, time_slots)
                population.append(timetable)
            except Exception as e:
                logger.warning(f"Failed to create a random timetable: {str(e)}")
                # Continue trying to create the population
                continue
        
        if not population:
            raise ValueError("Could not create initial population. Check your input data.")
        
        # Evolution parameters
        generations = 5  # Reduced for faster execution
        mutation_rate = 0.2
        
        best_timetable = population[0]
        best_fitness = calculate_fitness(best_timetable)
        
        # Main evolution loop
        for generation in range(generations):
            logger.info(f"Generation {generation+1}/{generations}")
            
            # Evaluate fitness for each timetable
            fitness_scores = []
            for timetable in population:
                fitness = calculate_fitness(timetable)
                fitness_scores.append(fitness)
                
                # Update best timetable if needed
                if fitness > best_fitness:
                    best_timetable = timetable
                    best_fitness = fitness
            
            # Create new population
            new_population = [best_timetable]  # Elitism: keep the best timetable
            
            while len(new_population) < population_size:
                # Select parents
                parent1 = select_parent(population, fitness_scores)
                parent2 = select_parent(population, fitness_scores)
                
                # Create child through crossover
                child = crossover(parent1, parent2)
                
                # Apply mutation
                if random.random() < mutation_rate:
                    mutate(child, subjects, teachers, rooms, time_slots)
                
                new_population.append(child)
            
            population = new_population
        
        # Calculate conflicts and utilization for the best timetable
        conflicts = count_conflicts(best_timetable)
        utilization = calculate_utilization(best_timetable)
        
        best_timetable.conflicts = conflicts
        best_timetable.utilization = utilization
        
        logger.info(f"Timetable generation completed. Conflicts: {conflicts}, Utilization: {utilization}%")
        
        return best_timetable
        
    except Exception as e:
        logger.error(f"Error in timetable generation: {str(e)}")
        # Create a simple timetable with the error message
        error_timetable = Timetable(schedule={})
        error_timetable.error = str(e)
        return error_timetable

def create_random_timetable(subjects, teachers, rooms, time_slots):
    """Create a random timetable as a starting point for the genetic algorithm."""
    timetable = Timetable(schedule={})
    
    # Initialize the schedule structure
    for time_slot in time_slots:
        day = time_slot.day
        time = f"{time_slot.start_time}-{time_slot.end_time}"
        
        if day not in timetable.schedule:
            timetable.schedule[day] = {}
        if time not in timetable.schedule[day]:
            timetable.schedule[day][time] = []
    
    # For each subject, assign sessions
    for subject in subjects:
        # Handle lecture sessions
        for _ in range(subject.required_sessions):
            # Find qualified teachers for this subject
            qualified_teachers = [t for t in teachers if subject.id in t.subjects]
            if not qualified_teachers:
                logger.warning(f"No qualified teachers for subject {subject.name}. Skipping.")
                continue
                
            # Randomly select a teacher, room, and time slot
            teacher = random.choice(qualified_teachers)
            room = random.choice([r for r in rooms if not r.is_lab])  # Regular rooms for lectures
            if not room:
                room = random.choice(rooms)  # Fallback to any room if no regular rooms
                
            time_slot = random.choice(time_slots)
            
            # Create a session
            session = TimetableSession(
                subject=subject,
                teacher=teacher,
                room=room,
                time_slot=time_slot,
                is_practical=False
            )
            
            # Add to timetable
            day = time_slot.day
            time = f"{time_slot.start_time}-{time_slot.end_time}"
            
            if day not in timetable.schedule:
                timetable.schedule[day] = {}
            if time not in timetable.schedule[day]:
                timetable.schedule[day][time] = []
                
            timetable.schedule[day][time].append(session)
        
        # Handle practical sessions if applicable
        if subject.has_practical and subject.practical_sessions_per_week > 0:
            for _ in range(subject.practical_sessions_per_week):
                # Find qualified teachers
                qualified_teachers = [t for t in teachers if subject.id in t.subjects]
                if not qualified_teachers:
                    logger.warning(f"No qualified teachers for subject {subject.name} practical. Skipping.")
                    continue
                
                # Find lab rooms
                lab_rooms = [r for r in rooms if r.is_lab]
                if not lab_rooms:
                    logger.warning(f"No lab rooms available for subject {subject.name} practical. Using regular room.")
                    lab_rooms = rooms  # Fallback to any room
                
                # Randomly select
                teacher = random.choice(qualified_teachers)
                room = random.choice(lab_rooms)
                time_slot = random.choice(time_slots)
                
                # Create a session
                session = TimetableSession(
                    subject=subject,
                    teacher=teacher,
                    room=room,
                    time_slot=time_slot,
                    is_practical=True
                )
                
                # Add to timetable
                day = time_slot.day
                time = f"{time_slot.start_time}-{time_slot.end_time}"
                
                if day not in timetable.schedule:
                    timetable.schedule[day] = {}
                if time not in timetable.schedule[day]:
                    timetable.schedule[day][time] = []
                    
                timetable.schedule[day][time].append(session)
    
    return timetable

def add_session_to_timetable(timetable, session):
    day = session.time_slot.day
    time = f"{session.time_slot.start_time}-{session.time_slot.end_time}"

    if day not in timetable.schedule:
        timetable.schedule[day] = {}
    if time not in timetable.schedule[day]:
        timetable.schedule[day][time] = []

    timetable.schedule[day][time].append(session)

def calculate_fitness(timetable):
    """Calculate the fitness score for a timetable. Higher is better."""
    fitness = 1000  # Base fitness
    
    # Penalize for conflicts
    conflicts = count_conflicts(timetable)
    fitness -= conflicts * 100
    
    # Penalize for constraint violations
    constraint_violations = check_constraints(timetable)
    fitness -= constraint_violations * 50
    
    return max(0, fitness)

def count_conflicts(timetable):
    """Count the number of conflicts in a timetable."""
    conflicts = 0
    
    # Check for teacher conflicts (same teacher, same time)
    teacher_assignments = {}
    
    # Check for room conflicts (same room, same time)
    room_assignments = {}
    
    for day, time_slots in timetable.schedule.items():
        for time, sessions in time_slots.items():
            for session in sessions:
                # Check teacher conflicts
                teacher_key = f"{session.teacher.id}-{day}-{time}"
                if teacher_key in teacher_assignments:
                    conflicts += 1
                else:
                    teacher_assignments[teacher_key] = True
                
                # Check room conflicts
                room_key = f"{session.room.id}-{day}-{time}"
                if room_key in room_assignments:
                    conflicts += 1
                else:
                    room_assignments[room_key] = True
    
    return conflicts

def check_constraints(timetable):
    """Check for constraint violations in the timetable."""
    violations = 0
    
    # This is a simplified version. In a real implementation, you would check:
    # - Teacher's maximum hours per day
    # - Room suitability for the subject
    # - Preferred time slots for teachers
    # - Lunch breaks
    # - etc.
    
    return violations

def select_parents(population, fitness_scores):
    total_fitness = sum(fitness_scores)
    selection_probs = [score / total_fitness for score in fitness_scores]
    return random.choices(population, weights=selection_probs, k=len(population))

def select_parent(population, fitness_scores):
    """Select a parent for reproduction using tournament selection."""
    # Tournament selection
    tournament_size = min(3, len(population))
    tournament_indices = random.sample(range(len(population)), tournament_size)
    
    # Find the best individual in the tournament
    best_index = tournament_indices[0]
    best_fitness = fitness_scores[best_index]
    
    for idx in tournament_indices[1:]:
        if fitness_scores[idx] > best_fitness:
            best_index = idx
            best_fitness = fitness_scores[idx]
    
    return population[best_index]

def crossover(parent1, parent2):
    """Create a new timetable by combining two parent timetables."""
    child = Timetable(schedule={})
    
    # Get all days from both parents
    all_days = set(list(parent1.schedule.keys()) + list(parent2.schedule.keys()))
    
    for day in all_days:
        child.schedule[day] = {}
        
        # Get all time slots for this day from both parents
        all_times = set()
        if day in parent1.schedule:
            all_times.update(parent1.schedule[day].keys())
        if day in parent2.schedule:
            all_times.update(parent2.schedule[day].keys())
        
        for time in all_times:
            # Randomly choose sessions from either parent
            if random.random() < 0.5 and day in parent1.schedule and time in parent1.schedule[day]:
                child.schedule[day][time] = parent1.schedule[day][time].copy()
            elif day in parent2.schedule and time in parent2.schedule[day]:
                child.schedule[day][time] = parent2.schedule[day][time].copy()
            else:
                child.schedule[day][time] = []
    
    return child

def mutate(timetable, subjects, teachers, rooms, time_slots):
    """Apply random mutations to a timetable."""
    if not timetable.schedule:
        return  # Nothing to mutate
        
    # Select a random day and time
    days = list(timetable.schedule.keys())
    if not days:
        return  # No days in schedule
        
    day = random.choice(days)
    
    times = list(timetable.schedule[day].keys())
    if not times:
        return  # No times for this day
        
    time = random.choice(times)
    
    sessions = timetable.schedule[day][time]
    if not sessions:
        return  # No sessions at this time
        
    # Select a random session
    session_idx = random.randrange(len(sessions))
    session = sessions[session_idx]
    
    # Decide what to mutate
    mutation_type = random.choice(['teacher', 'room', 'time'])
    
    if mutation_type == 'teacher':
        # Find qualified teachers for this subject
        qualified_teachers = [t for t in teachers if session.subject.id in t.subjects]
        if qualified_teachers:
            session.teacher = random.choice(qualified_teachers)
            
    elif mutation_type == 'room':
        # Choose appropriate room type
        if session.is_practical:
            suitable_rooms = [r for r in rooms if r.is_lab]
            if not suitable_rooms:
                suitable_rooms = rooms  # Fallback
        else:
            suitable_rooms = [r for r in rooms if not r.is_lab]
            if not suitable_rooms:
                suitable_rooms = rooms  # Fallback
                
        if suitable_rooms:
            session.room = random.choice(suitable_rooms)
            
    elif mutation_type == 'time':
        # Move to a different time slot
        new_time_slot = random.choice(time_slots)
        
        # Remove from current time slot
        timetable.schedule[day][time].pop(session_idx)
        
        # Add to new time slot
        new_day = new_time_slot.day
        new_time = f"{new_time_slot.start_time}-{new_time_slot.end_time}"
        
        if new_day not in timetable.schedule:
            timetable.schedule[new_day] = {}
        if new_time not in timetable.schedule[new_day]:
            timetable.schedule[new_day][new_time] = []
            
        session.time_slot = new_time_slot
        timetable.schedule[new_day][new_time].append(session)

def calculate_utilization(timetable):
    """Calculate resource utilization percentage."""
    # This is a simplified calculation
    total_slots = 0
    used_slots = 0
    
    for day, time_slots in timetable.schedule.items():
        for time, sessions in time_slots.items():
            total_slots += 1
            if sessions:
                used_slots += 1
    
    if total_slots == 0:
        return 0
        
    return round((used_slots / total_slots) * 100)

