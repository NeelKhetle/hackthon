from flask import Flask, render_template, request, jsonify, send_file
from models.timetable import Subject, Teacher, Room, TimeSlot, Timetable, TimetableSession
from utils.genetic_algorithm import generate_timetable
from utils.pdf_generator import generate_pdf
import csv
import io
import logging
from flask_cors import CORS

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# In-memory storage (replace with a database in a production environment)
subjects = []
teachers = []
rooms = []
time_slots = []
timetable = None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/input_forms')
def input_forms():
    return render_template('input_forms.html')

@app.route('/batch_input')
def batch_input():
    return render_template('batch_input.html')

@app.route('/timetable_view')
def timetable_view():
    return render_template('timetable_view.html', timetable=timetable)

@app.route('/api/add_subject', methods=['POST'])
def add_subject():
    try:
        data = request.get_json()
        
        required_fields = ['code', 'name', 'department', 'credits', 'requiredSessions']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400

        subject = Subject(
            id=data['code'],
            code=data['code'],
            name=data['name'],
            department=data['department'],
            credits=int(data['credits']),
            required_sessions=int(data['requiredSessions']),
            has_practical=data.get('hasPractical', False),
            practical_duration=int(data.get('practicalDuration', 0)),
            practical_sessions_per_week=int(data.get('practicalSessionsPerWeek', 0))
        )
        
        subjects.append(subject)
        
        return jsonify({"message": "Subject added successfully", "subject": subject.__dict__}), 201
        
    except Exception as e:
        logger.error(f"Error adding subject: {str(e)}")
        return jsonify({"error": "Internal server error", "message": str(e)}), 500

@app.route('/api/add_teacher', methods=['POST'])
def add_teacher():
    try:
        data = request.get_json()
        
        required_fields = ['id', 'name', 'department']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400

        teacher = Teacher(
            id=data['id'],
            name=data['name'],
            department=data['department'],
            subjects=data.get('subjects', []),
            max_hours_per_day=int(data.get('maxHoursPerDay', 6)),
            preferred_time_slots=data.get('preferredTimeSlots', [])
        )
        
        teachers.append(teacher)
        
        return jsonify({"message": "Teacher added successfully", "teacher": teacher.__dict__}), 201
        
    except Exception as e:
        logger.error(f"Error adding teacher: {str(e)}")
        return jsonify({"error": "Internal server error", "message": str(e)}), 500

@app.route('/api/add_room', methods=['POST'])
def add_room():
    try:
        data = request.get_json()
        
        required_fields = ['id', 'name', 'capacity']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400

        room = Room(
            id=data['id'],
            name=data['name'],
            capacity=int(data['capacity']),
            has_projector=data.get('hasProjector', False),
            has_computers=data.get('hasComputers', False),
            is_lab=data.get('isLab', False),
            lab_type=data.get('labType', '')
        )
        
        rooms.append(room)
        
        return jsonify({"message": "Room added successfully", "room": room.__dict__}), 201
        
    except Exception as e:
        logger.error(f"Error adding room: {str(e)}")
        return jsonify({"error": "Internal server error", "message": str(e)}), 500

@app.route('/api/add_time_slot', methods=['POST'])
def add_time_slot():
    try:
        data = request.get_json()
        
        required_fields = ['day', 'startTime', 'endTime']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing required field: {field}"}), 400

        time_slot = TimeSlot(
            id=f"{data['day']}-{data['startTime']}-{data['endTime']}",
            day=data['day'],
            start_time=data['startTime'],
            end_time=data['endTime']
        )
        
        time_slots.append(time_slot)
        
        return jsonify({"message": "Time slot added successfully", "timeSlot": time_slot.__dict__}), 201
        
    except Exception as e:
        logger.error(f"Error adding time slot: {str(e)}")
        return jsonify({"error": "Internal server error", "message": str(e)}), 500

@app.route('/api/generate_timetable', methods=['POST'])
def api_generate_timetable():
    global timetable
    
    try:
        # Validate that we have enough data to generate a timetable
        if not subjects:
            return jsonify({"error": "No subjects available. Please add subjects first."}), 400
        if not teachers:
            return jsonify({"error": "No teachers available. Please add teachers first."}), 400
        if not rooms:
            return jsonify({"error": "No rooms available. Please add rooms first."}), 400
        if not time_slots:
            return jsonify({"error": "No time slots available. Please add time slots first."}), 400
            
        # Check if teachers are assigned to subjects
        teacher_subject_count = sum(len(teacher.subjects) for teacher in teachers)
        if teacher_subject_count == 0:
            return jsonify({"error": "No teachers are assigned to subjects. Please assign subjects to teachers."}), 400
            
        # Generate the timetable
        logger.info("Starting timetable generation")
        timetable = generate_timetable(subjects, teachers, rooms, time_slots)
        
        # Check if there was an error during generation
        if hasattr(timetable, 'error'):
            return jsonify({"error": f"Error generating timetable: {timetable.error}"}), 500
            
        logger.info("Timetable generation completed successfully")
        return jsonify({
            "message": "Timetable generated successfully",
            "conflicts": timetable.conflicts,
            "utilization": timetable.utilization
        }), 200
        
    except Exception as e:
        logger.error(f"Error generating timetable: {str(e)}")
        return jsonify({"error": f"Error generating timetable: {str(e)}"}), 500

@app.route('/api/export_pdf')
def export_pdf():
    if not timetable:
        return jsonify({"error": "No timetable generated yet"}), 400
    
    try:
        pdf_buffer = generate_pdf(timetable)
        pdf_buffer.seek(0)
        
        return send_file(
            pdf_buffer,
            as_attachment=True,
            download_name="timetable.pdf",
            mimetype="application/pdf"
        )
    except Exception as e:
        logger.error(f"Error exporting PDF: {str(e)}")
        return jsonify({"error": f"Error exporting PDF: {str(e)}"}), 500

@app.route('/api/export_csv')
def export_csv():
    if not timetable:
        return jsonify({"error": "No timetable generated yet"}), 400
    
    try:
        csv_buffer = io.StringIO()
        csv_writer = csv.writer(csv_buffer)
        
        csv_writer.writerow(["Day", "Time", "Subject", "Teacher", "Room", "Type"])
        
        for day, slots in timetable.schedule.items():
            for time, sessions in slots.items():
                for session in sessions:
                    csv_writer.writerow([
                        day,
                        time,
                        session.subject.name,
                        session.teacher.name,
                        session.room.name,
                        "Practical" if session.is_practical else "Lecture"
                    ])
        
        csv_buffer.seek(0)
        return send_file(
            io.BytesIO(csv_buffer.getvalue().encode()),
            as_attachment=True,
            download_name="timetable.csv",
            mimetype="text/csv"
        )
    except Exception as e:
        logger.error(f"Error exporting CSV: {str(e)}")
        return jsonify({"error": f"Error exporting CSV: {str(e)}"}), 500

# Add these new routes for getting counts and lists
@app.route('/api/subject_count')
def get_subject_count():
    return jsonify({"count": len(subjects)})

@app.route('/api/teacher_count')
def get_teacher_count():
    return jsonify({"count": len(teachers)})

@app.route('/api/room_count')
def get_room_count():
    return jsonify({"count": len(rooms)})

@app.route('/api/subjects')
def get_subjects():
    return jsonify([{
        "id": subject.id,
        "code": subject.code,
        "name": subject.name,
        "department": subject.department,
        "credits": subject.credits,
        "requiredSessions": subject.required_sessions,
        "hasPractical": subject.has_practical,
        "practicalDuration": subject.practical_duration,
        "practicalSessionsPerWeek": subject.practical_sessions_per_week
    } for subject in subjects])

@app.route('/api/teachers')
def get_teachers():
    return jsonify([{
        "id": teacher.id,
        "name": teacher.name,
        "department": teacher.department,
        "subjects": teacher.subjects,
        "maxHoursPerDay": teacher.max_hours_per_day
    } for teacher in teachers])

@app.route('/api/rooms')
def get_rooms():
    return jsonify([{
        "id": room.id,
        "name": room.name,
        "capacity": room.capacity,
        "hasProjector": room.has_projector,
        "hasComputers": room.has_computers,
        "isLab": room.is_lab,
        "labType": room.lab_type
    } for room in rooms])

@app.route('/api/time_slots')
def get_time_slots():
    return jsonify([{
        "id": slot.id,
        "day": slot.day,
        "startTime": slot.start_time,
        "endTime": slot.end_time
    } for slot in time_slots])

@app.route('/api/timetable')
def get_timetable():
    if not timetable:
        return jsonify({"error": "No timetable generated yet"}), 400
    
    try:
        view_type = request.args.get('viewType', 'master')
        entity_id = request.args.get('entityId')
        
        # Get all days and time slots
        days = sorted(list(timetable.schedule.keys()))
        all_time_slots = sorted(list(set(time for day_schedule in timetable.schedule.values() for time in day_schedule.keys())))
        
        # Create a filtered schedule based on view type
        filtered_schedule = {}
        
        if view_type == 'master' or not entity_id:
            # Return the full timetable
            filtered_schedule = timetable.schedule
        elif view_type == 'teacher':
            # Filter for a specific teacher
            for day in days:
                filtered_schedule[day] = {}
                for time in all_time_slots:
                    if day in timetable.schedule and time in timetable.schedule[day]:
                        teacher_sessions = [
                            session for session in timetable.schedule[day][time]
                            if session.teacher.id == entity_id
                        ]
                        if teacher_sessions:
                            filtered_schedule[day][time] = teacher_sessions
        elif view_type == 'room':
            # Filter for a specific room
            for day in days:
                filtered_schedule[day] = {}
                for time in all_time_slots:
                    if day in timetable.schedule and time in timetable.schedule[day]:
                        room_sessions = [
                            session for session in timetable.schedule[day][time]
                            if session.room.id == entity_id
                        ]
                        if room_sessions:
                            filtered_schedule[day][time] = room_sessions
        
        # Convert the timetable to a format suitable for the frontend
        result = {
            "days": days,
            "timeSlots": all_time_slots,
            "schedule": {}
        }
        
        # Convert the schedule to a simpler format for JSON serialization
        for day in filtered_schedule:
            result["schedule"][day] = {}
            for time in filtered_schedule[day]:
                result["schedule"][day][time] = []
                for session in filtered_schedule[day][time]:
                    result["schedule"][day][time].append({
                        "subject": session.subject.name,
                        "teacher": session.teacher.name,
                        "room": session.room.name,
                        "isPractical": session.is_practical
                    })
        
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error retrieving timetable: {str(e)}")
        return jsonify({"error": f"Error retrieving timetable: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True)

